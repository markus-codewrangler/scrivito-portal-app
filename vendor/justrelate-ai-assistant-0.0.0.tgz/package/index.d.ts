export declare function init(initConfig: InitConfig): void;

declare interface InitConfig {
    botId: string;
}

export declare function openNewConversation({ userPrompt, }?: {
    userPrompt?: string;
}): void;

export declare function resumeConversation(): void;

export declare function subscribeToVisibility(callback: (visible: boolean) => void): () => void;

export declare function useAssistantVisible(): boolean;

export { }
